// Iso theme · direction mockup v1.
// node site-src/build.mjs  →  index.html, projects.html, favicon.svg at the repo root.
// NOTE: index.html has since been edited by hand (contribution card, hover effects, local images);
// regenerating will overwrite those edits.
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import * as k from "../.claude/skills/anatomy/kit/iso-kit.mjs";
import { kitScript } from "../.claude/skills/anatomy/scripts/inline-kit.mjs";
import { deskFigure } from "./fig-desk.mjs";
import { contribFigure } from "./fig-contrib.mjs";
import { markSvg } from "./fig-mark.mjs";
import { gearsFigure } from "./fig-gears.mjs";
import { rackFigure } from "./fig-rack.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, "..");
const USER = "aniruddha-chaudhari";
const EMAIL = "aniruddhachaudhari2704@gmail.com";
const CV = "https://drive.google.com/file/d/1VQ517xCgiIP63xAu2NYI6ZcuSX-mp4mw/view?usp=sharing";

const projects = JSON.parse(readFileSync(join(HERE, "data/projects.json"), "utf8")).projects;
const contributions = JSON.parse(readFileSync(join(HERE, "data/contributions.json"), "utf8"));

const desk = deskFigure();
const gearsFig = gearsFigure();


const ROLE = "Software engineer. I build full-stack products with applied AI.";
const meta = (title) => `<meta name="description" content="${ROLE}">
<link rel="icon" href="favicon.svg" type="image/svg+xml">
<meta property="og:type" content="website"><meta property="og:title" content="${title}"><meta property="og:description" content="${ROLE}">
<meta property="og:image" content="og.png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="Aniruddha Chaudhari, software engineer, beside an isometric drawing of a desk and monitor">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="og.png">`;
const tower = contribFigure(contributions, { username: USER });

const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const sentence = (s) => (s ? s[0].toUpperCase() + s.slice(1).replace(/\s*\.?$/, ".") : "");

const copyIcons = `<svg class="ico-copy" viewBox="0 0 16 16" aria-hidden="true"><rect x="5" y="5" width="8.5" height="8.5" rx="1.8"/><path d="M10.5 5V3.6A1.6 1.6 0 0 0 8.9 2H3.6A1.6 1.6 0 0 0 2 3.6v5.3a1.6 1.6 0 0 0 1.6 1.6H5"/></svg><svg class="ico-check" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5l3.2 3.2L13 4.8"/></svg>`;
const LINKEDIN = "https://www.linkedin.com/in/aniruddha2704/";
const socials = `<ul class="socials" aria-label="Elsewhere">
  <li><a href="https://github.com/${USER}" target="_blank" rel="noopener"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>GitHub</a></li>
  <li><a href="${LINKEDIN}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zm1.78 13.02H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0z"/></svg>LinkedIn</a></li>
</ul>`;
const arrow = `<svg class="ico" viewBox="0 0 12 12" aria-hidden="true"><path d="M3.5 8.5l5-5M4.5 3.5h4v4"/></svg>`;

// tags: one key per technology, so "Reactjs" and "React" filter together
const TAG_LABEL = { nextjs: "Next.js", tailwindcss: "Tailwind", fastapi: "FastAPI", react: "React", gemini: "Gemini", zustand: "Zustand", mongodb: "MongoDB", threejs: "Three.js", phaserjs: "Phaser", "node.js": "Node.js", express: "Express", pinecone: "Pinecone", qdrant: "Qdrant", langchain: "LangChain", neon: "Neon", prisma: "Prisma", vite: "Vite" };
const tagKey = (t) => { const k = t.toLowerCase(); return k === "reactjs" ? "react" : k; };
const tagLabel = (t) => TAG_LABEL[tagKey(t)] || t;

function projectRow(p) {
  const live = Boolean(p.live);
  const tags = p.tags.slice(0, 3).map((t) => esc(tagLabel(t))).join(" · ");
  const links = [
    live ? `<a href="${esc(p.live)}" target="_blank" rel="noopener">live ${arrow}</a>` : "",
    p.repo ? `<a href="${esc(p.repo)}" target="_blank" rel="noopener">code ${arrow}</a>` : "",
  ].join("");
  return `<li class="idx" data-shot="${esc(p.image)}">
  <img class="idx-thumb" src="${esc(p.image)}" alt="" loading="lazy">
  <a class="idx-name" href="${esc(p.live || p.repo)}" target="_blank" rel="noopener"><span class="dot" data-live="${live}" title="${live ? "Live" : "Code only"}"></span>${esc(p.title)}</a>
  <div class="idx-text"><p>${esc(sentence(p.description))}</p><p class="idx-stack">${tags}</p></div>
  <div class="idx-links">${links}</div>
</li>`;
}

const featured = projects.filter((p) => p.featured);
const rest = projects.filter((p) => !p.featured);

const stack = ["React", "Next.js", "TypeScript", "FastAPI", "Express", "PostgreSQL", "MongoDB", "React Native", "Docker", "AWS EC2", "LangChain", "Gemini"];

const themeIcon = `<svg class="tm" viewBox="0 0 24 24" aria-hidden="true"><g class="tm-sun"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.4 5.4l1.5 1.5M17.1 17.1l1.5 1.5M5.4 18.6l1.5-1.5M17.1 6.9l1.5-1.5"/></g><g class="tm-moon"><path d="M20 14.6A8.4 8.4 0 0 1 9.4 4a8.4 8.4 0 1 0 10.6 10.6z"/></g></svg>`;
function header(page) {
  const home = page === "home" ? "" : "index.html";
  return `  <header class="top">
    <a class="brand" href="${home}#top" aria-label="Aniruddha Chaudhari, home"><span>aniruddha.dev</span></a>
    <nav>
      <a href="projects.html"${page === "projects" ? ' aria-current="page"' : ""}>Projects</a>
      <a href="${home}#about">About</a>
      <a href="${home}#github">GitHub</a>
      <button class="theme" type="button" data-theme-toggle aria-label="Switch theme">${themeIcon}<span class="theme-tip" aria-hidden="true"></span></button>
    </nav>
  </header>`;
}



const body = `
<div class="peek" aria-hidden="true"><img alt=""></div>
<span class="sr" role="status" aria-live="polite" data-copy-status></span>
<div class="wrap">
${header("home")}

  <main id="top">
    <section class="hero">
      <div class="hero-text">
        <div>
          <h1>Aniruddha Chaudhari</h1>
          <p class="role">Software engineer. I build full-stack products with applied AI.</p>
          <p class="lede">I craft performant, resilient interfaces with a focus on clean architecture, great UX and maintainable code.</p>
        </div>
        <div class="actions">
          <a class="btn btn-solid" href="#projects">View projects</a>
          <a class="btn" href="${CV}" target="_blank" rel="noopener">Download CV</a>
          <button class="btn btn-ghost" type="button" data-copy="${EMAIL}">${copyIcons}<span class="copy-label">Copy email</span></button>
        </div>
      </div>
      <figure class="fig hero-fig" id="fig-desk">
        ${desk.svg}
      </figure>
      ${socials}
    </section>

    <section class="rows" id="about" aria-label="About">
      <div class="row"><h2>Currently</h2><p><span class="todo">Write one or two sentences on what you're building or learning right now.</span></p></div>
      <div class="row"><h2>Focus</h2><p>Full-stack web and applied AI: Next.js front ends, FastAPI services, and retrieval agents on Gemini with Pinecone or Qdrant.</p></div>
      <div class="row"><h2>Stack</h2><p class="inline-list">${stack.map((s) => `<span>${s}</span>`).join("")}</p></div>
    </section>

    <section class="block" id="projects">
      <div class="block-head"><h2>Selected projects</h2><a class="link" href="projects.html">All projects ${arrow}</a></div>
      <ul class="index">${featured.map(projectRow).join("")}</ul>
    </section>

    <section class="block" id="github">
      <div class="block-head"><h2>GitHub activity</h2><a class="link" href="https://github.com/${USER}" target="_blank" rel="noopener">@${USER} ${arrow}</a></div>
      <figure class="fig fig-wide" id="fig-contrib">
        <div class="fig-corners" aria-hidden="true"><span data-c="hint">Hover a day</span><span data-c="readout" data-readout></span></div>
        ${tower.svg}
        <span class="sr" role="status" aria-live="polite" data-status></span>
      </figure>
      <div class="fig-foot">
        <button class="btn" type="button" data-raise aria-pressed="false">Raise it</button>
      </div>
    </section>

    <section class="block contact" id="contact">
      <div class="contact-text">
        <div>
          <h2 class="contact-line">Have something to build? I'm one email away.</h2>
          <p class="contact-note">Websites, web apps and AI features, from the first sketch to launch.</p>
        </div>
        <div>
        <div class="actions">
        <button class="btn btn-solid" type="button" data-copy="${EMAIL}">${copyIcons}<span class="copy-label">Copy email</span></button>
        <a class="btn" href="${LINKEDIN}" target="_blank" rel="noopener">LinkedIn ${arrow}</a>
        <a class="btn" href="https://github.com/${USER}" target="_blank" rel="noopener">GitHub ${arrow}</a>
      </div>
        <p class="email-plain">${EMAIL}</p>
        </div>
      </div>
      <figure class="fig contact-fig" id="fig-gears">${gearsFig.svg}
      </figure>
    </section>
  </main>

  <footer class="foot"><span>© 2026 Aniruddha Chaudhari</span><span>Iso theme · mockup v1</span></footer>
</div>`;

const css = `
/* Layout: one 720px reading column; label-left rows; figures framed like plates in a manual. */
.iso{
  --accent:#ededed; --accent-hi:#ffffff; --green:#4ade80;
  --glow:url(#cb-glow); --glow-fig:url(#dk-glow); --pool:.07; --bloom:.12; --screen-haze:.06;
  --rule:#ffffff14; --btn:#ffffff0d; --btn-hi:#ffffff1a; --solid:#ededed; --solid-ink:#0b0b0b;
  --sans:"Geist",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
  --anatomy-mono:"Geist Mono",ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  color-scheme:dark;
}
.iso[data-theme="light"]{
  --anatomy-text:#3b3b40; --anatomy-muted:#66666c; --anatomy-strong:#0b0b0c;
  --accent:#171717; --accent-hi:#0a0a0a; --green:#16a34a;
  --glow:none; --glow-fig:none; --pool:0; --bloom:0; --screen-haze:.04;
  --rule:#00000014; --btn:#0000000a; --btn-hi:#00000014; --solid:#18181a; --solid-ink:#fbfbfa;
  color-scheme:light;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
@media (prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
body{margin:0;background:var(--anatomy-page);color:var(--anatomy-text);font:15px/1.65 var(--sans);-webkit-font-smoothing:antialiased;min-height:100vh}
.wrap{position:relative;z-index:1;width:min(760px,100% - 32px);margin:0 auto;padding-block:20px 48px}
a{color:inherit}
h1,h2,h3{color:var(--anatomy-strong);font-weight:500;margin:0;text-wrap:balance}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
.ico{width:11px;height:11px;flex:none;fill:none;stroke:currentColor;stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round}

/* header */
.top{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:8px 16px;margin-inline:-16px;position:sticky;top:env(safe-area-inset-top,0px);z-index:5;background:transparent;border-bottom:1px solid transparent;transition:background .25s,border-color .25s}
.top[data-scrolled]{background:color-mix(in oklab,var(--anatomy-page) 86%,transparent);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom-color:var(--rule)}
.brand{display:inline-flex;align-items:center;gap:10px;text-decoration:none;color:var(--anatomy-strong);font-family:var(--anatomy-mono);font-size:12.5px;letter-spacing:.02em}
.top nav{display:flex;align-items:center;gap:4px}
.top nav>a:not(.btn){font-size:13.5px;text-decoration:none;padding:6px 10px;border-radius:999px;color:var(--anatomy-text)}
.top nav>a:not(.btn):hover{color:var(--anatomy-strong)}
.theme{width:32px;height:32px;display:grid;place-items:center;border:0;border-radius:999px;background:transparent;color:var(--anatomy-text);cursor:pointer}
.theme:hover{color:var(--anatomy-strong);background:var(--btn)}
.theme{position:relative}
.theme-tip{position:absolute;right:0;top:calc(100% + 6px);transform:translateY(-4px);padding:4px 8px;border-radius:6px;background:var(--solid);color:var(--solid-ink);font:500 12px/1 var(--sans);white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .15s,transform .15s}
.theme:hover .theme-tip,.theme:focus-visible .theme-tip{opacity:1;transform:none}
.tm{width:17px;height:17px;overflow:visible}
.tm circle,.tm path{fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}
.tm-sun,.tm-moon{transform-box:view-box;transform-origin:12px 12px;transition:transform .45s cubic-bezier(.4,1.3,.5,1),opacity .25s}
.iso:not([data-theme="light"]) .tm-moon{opacity:0;transform:rotate(-90deg) scale(.5)}
.iso[data-theme="light"] .tm-sun{opacity:0;transform:rotate(90deg) scale(.5)}
@media (prefers-reduced-motion:reduce){.tm-sun,.tm-moon{transition:none}}



/* buttons: flat, straight */
.btn{display:inline-flex;align-items:center;gap:7px;height:36px;padding:0 14px;border-radius:8px;border:1px solid var(--rule);background:var(--btn);color:var(--anatomy-strong);font:500 13.5px/1 var(--sans);text-decoration:none;cursor:pointer;white-space:nowrap;transition:background .2s,border-color .2s}
.btn:hover{background:var(--btn-hi)}
.btn-solid{background:var(--solid);color:var(--solid-ink);border-color:transparent}
.btn-solid:hover{background:var(--solid);opacity:.88}
.btn-ghost{background:transparent;border-color:transparent;color:var(--anatomy-text)}
.btn-ghost:hover{color:var(--anatomy-strong);background:var(--btn)}
.btn:focus-visible,.theme:focus-visible,a:focus-visible{outline:2px solid var(--anatomy-strong);outline-offset:2px}
.btn[data-done]{color:var(--green)}
.ico-copy,.ico-check{width:14px;height:14px;flex:none;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}
.ico-check{display:none}
[data-done] .ico-copy{display:none}
[data-done] .ico-check{display:block}

/* hero */
.hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,410px);gap:28px 32px;align-items:stretch;padding-block:56px 32px}
.hero-text{display:flex;flex-direction:column;justify-content:space-between;gap:24px}
.hero-fig{padding:18px 2px}
.hero .actions{margin-top:0}
.hero h1{font-size:clamp(30px,5.4vw,40px);line-height:1.1;letter-spacing:-.025em}
.role{margin:10px 0 0;font-size:18px;line-height:1.45;color:var(--anatomy-strong);opacity:.86;max-width:30ch;text-wrap:balance}
.lede{margin:12px 0 0;max-width:46ch}
.actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:22px}
.socials{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:4px 20px;list-style:none;margin:0;padding:14px 0 0;border-top:1px solid var(--rule)}
.socials a{display:inline-flex;align-items:center;gap:7px;font-size:13.5px;text-decoration:none;color:var(--anatomy-text);padding:4px 0}
.socials a:hover{color:var(--anatomy-strong)}
.socials svg{width:15px;height:15px;fill:currentColor;flex:none}

/* figures */
.fig{position:relative;margin:0;background:var(--anatomy-card);box-shadow:0 0 0 1px var(--rule);--anatomy-paper:var(--anatomy-card)}
.fig-corners span{position:absolute;font-family:var(--anatomy-mono);font-size:10.5px;line-height:1;letter-spacing:.04em;color:var(--anatomy-muted);white-space:nowrap;pointer-events:none}
.fig-corners [data-c="hint"]{bottom:14px;left:16px;text-transform:uppercase;letter-spacing:.1em}
.fig-corners [data-c="readout"]{bottom:14px;right:16px;color:var(--anatomy-text);font-variant-numeric:tabular-nums}
.fig-wide{padding:22px 12px 36px}
.fig .iso-svg{display:block;width:100%;height:auto}
.fig-foot{display:flex;justify-content:flex-end;margin-top:12px}

/* about rows */
.rows{border-top:1px solid var(--rule)}
.row{display:grid;grid-template-columns:140px minmax(0,1fr);gap:16px;padding-block:18px;border-bottom:1px solid var(--rule)}
.row h2{font-size:13.5px;font-weight:400;color:var(--anatomy-muted);padding-top:1px}
.row p{margin:0;max-width:60ch;color:var(--anatomy-strong);opacity:.86}
.iso[data-theme="light"] .role,.iso[data-theme="light"] .row p{opacity:1}
.iso[data-theme="light"] .todo{color:#77777d;border-bottom-color:#a8a8ad}
.inline-list{display:flex;flex-wrap:wrap;gap:4px 14px}
.inline-list span{font-family:var(--anatomy-mono);font-size:13px}
.todo{color:var(--anatomy-muted);border-bottom:1px dashed var(--anatomy-lo)}

/* projects */
.block{padding-block:56px 0}
.block-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-bottom:20px}
.block-head h2{font-size:20px;letter-spacing:-.01em}
.count,.link{font-family:var(--anatomy-mono);font-size:12px;color:var(--anatomy-muted);text-decoration:none;display:inline-flex;gap:6px;align-items:center}
.link:hover{color:var(--anatomy-strong)}
.index{list-style:none;margin:0;padding:0;border-bottom:1px solid var(--rule)}
.idx{position:relative;display:grid;grid-template-columns:170px minmax(0,1fr) auto;gap:4px 24px;align-items:baseline;padding:16px 10px;margin-inline:-10px;border-top:1px solid var(--rule);transition:background .2s}
.idx:hover{background:var(--btn)}
.idx-thumb{display:none}
.idx-name{display:inline-flex;align-items:center;gap:10px;font-weight:500;color:var(--anatomy-strong);text-decoration:none}
.idx-name::after{content:"";position:absolute;inset:0}
.idx-name:focus-visible{outline:none}.idx:has(.idx-name:focus-visible){box-shadow:inset 0 0 0 1px var(--anatomy-mid)}
.dot{width:6px;height:6px;border-radius:50%;flex:none;box-shadow:inset 0 0 0 1px var(--anatomy-mid)}
.dot[data-live="true"]{background:var(--green);box-shadow:none}
.idx-text p{margin:0;font-size:14px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.idx-text .idx-stack{margin-top:4px;font-family:var(--anatomy-mono);font-size:11.5px;color:var(--anatomy-muted)}
.idx-links{position:relative;z-index:1;display:flex;gap:14px;font-family:var(--anatomy-mono);font-size:12px;white-space:nowrap}
.idx-links a{display:inline-flex;align-items:center;gap:5px;color:var(--anatomy-muted);text-decoration:none}
.idx-links a:hover{color:var(--anatomy-strong)}
.peek{position:fixed;left:0;top:0;z-index:6;width:300px;aspect-ratio:16/10;pointer-events:none;opacity:0;background:var(--anatomy-shade-1);box-shadow:0 0 0 1px var(--rule),6px 6px 0 0 var(--anatomy-shade-0),6px 6px 0 1px var(--rule),0 18px 40px -12px #0008;transition:opacity .18s}
.peek[data-on]{opacity:1}
.peek img{width:100%;height:100%;object-fit:cover;object-position:top;display:block}
@media (hover:none),(max-width:640px){
  .peek{display:none}
  .idx{grid-template-columns:72px minmax(0,1fr);gap:4px 14px;align-items:start}
  .idx-thumb{display:block;grid-row:span 3;width:72px;aspect-ratio:16/10;object-fit:cover;object-position:top;box-shadow:0 0 0 1px var(--rule)}
  .idx-links{grid-column:2}
}

.top nav a[aria-current="page"]{color:var(--anatomy-strong)}

/* projects page */
.page-head{padding-block:56px 8px;position:relative}
.rack-fig{position:absolute;right:0;top:24px;bottom:8px;margin:0;padding:6px;aspect-ratio:300/380}
.rack-fig .iso-svg{width:auto;height:100%;margin:0 auto}
.idx[data-hl]{background:var(--btn)}
.back{display:inline-flex;align-items:center;gap:6px;margin-bottom:22px;font-family:var(--anatomy-mono);font-size:12px;color:var(--anatomy-muted);text-decoration:none}
.back:hover{color:var(--anatomy-strong)}
.page-head h1{font-size:clamp(30px,5vw,40px);line-height:1.1;letter-spacing:-.025em}
.page-head p{margin:10px 0 0;max-width:52ch}
.index-all{margin-top:28px}

/* contact */
.contact{padding-block:72px 8px;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,320px);gap:28px 40px;align-items:stretch}
.contact-text{display:flex;flex-direction:column;justify-content:center;gap:22px}
.contact-note{margin:12px 0 0;max-width:40ch}
.contact .actions{margin-top:0}
.contact-fig{padding:18px 2px}
.contact-line{font-size:clamp(22px,4vw,28px);line-height:1.2;letter-spacing:-.02em;max-width:22ch}
.email-plain{margin:14px 0 0;font-family:var(--anatomy-mono);font-size:12px;color:var(--anatomy-muted);user-select:all}
.foot{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:72px;padding-top:18px;border-top:1px solid var(--rule);font-family:var(--anatomy-mono);font-size:11.5px;color:var(--anatomy-muted)}

@media (max-width:720px){
  .hero{grid-template-columns:1fr;padding-block:40px 28px}
  .hero-fig{margin:0 auto;max-width:440px;width:100%}
  .row{grid-template-columns:1fr;gap:4px}
  .top nav>a:not(.btn){display:none}
  .fig-wide{padding:22px 4px 40px}
  .contact{grid-template-columns:1fr}
  .contact-fig{margin:0 auto;max-width:340px;width:100%}
  .rack-fig{display:none}
}
`;

const pageScript = `
{
const body = document.body;
const topBar = document.querySelector(".top");
const onScroll = () => topBar.toggleAttribute("data-scrolled", scrollY > 8);
addEventListener("scroll", onScroll, { passive: true });
onScroll();
let saved = null;
try { saved = localStorage.getItem("iso-theme"); } catch (e) {}
const prefer = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
body.dataset.theme = saved || prefer;
const still = matchMedia("(prefers-reduced-motion: reduce)");
const toggle = document.querySelector("[data-theme-toggle]");
const tip = toggle.querySelector(".theme-tip");
function labelToggle() {
  const next = body.dataset.theme === "light" ? "dark" : "light";
  tip.textContent = next === "light" ? "Light mode" : "Dark mode";
  toggle.setAttribute("aria-label", "Switch to " + next + " mode");
}
labelToggle();
toggle.addEventListener("click", () => {
  body.dataset.theme = body.dataset.theme === "light" ? "dark" : "light";
  try { localStorage.setItem("iso-theme", body.dataset.theme); } catch (e) {}
  labelToggle();
});
const copyStatus = document.querySelector("[data-copy-status]");
document.querySelectorAll("[data-copy]").forEach((btn) => {
  const label = btn.querySelector(".copy-label");
  const text = label.textContent;
  let timer = 0;
  btn.addEventListener("click", async () => {
    clearTimeout(timer);
    try {
      await navigator.clipboard.writeText(btn.dataset.copy);
      btn.setAttribute("data-done", "");
      label.textContent = "Copied";
      if (copyStatus) copyStatus.textContent = "Email address copied";
    } catch (e) {
      label.textContent = btn.dataset.copy;
    }
    timer = setTimeout(() => { btn.removeAttribute("data-done"); label.textContent = text; if (copyStatus) copyStatus.textContent = ""; }, 2000);
  });
});
}
{
const peek = document.querySelector(".peek");
const img = peek && peek.querySelector("img");
const fine = matchMedia("(hover: hover) and (pointer: fine)");
const calm = matchMedia("(prefers-reduced-motion: reduce)");
let x = 0, y = 0, tx = 0, ty = 0, raf = 0, on = false;
function place() {
  const w = peek.offsetWidth, h = peek.offsetHeight;
  let nx = tx + 28, ny = ty - h / 2;
  if (nx + w > innerWidth - 12) nx = tx - w - 28;
  ny = Math.max(12, Math.min(innerHeight - h - 12, ny));
  const k = calm.matches ? 1 : 0.22;
  x += (nx - x) * k; y += (ny - y) * k;
  peek.style.transform = "translate(" + x.toFixed(1) + "px," + y.toFixed(1) + "px)";
  raf = on && (Math.abs(nx - x) > 0.5 || Math.abs(ny - y) > 0.5) ? requestAnimationFrame(place) : 0;
}
if (peek) document.querySelectorAll(".idx").forEach((row) => {
  row.addEventListener("pointerenter", (e) => {
    if (!fine.matches) return;
    img.src = row.dataset.shot;
    tx = e.clientX; ty = e.clientY;
    if (!on) { x = tx + 28; y = ty - 94; }
    on = true; peek.setAttribute("data-on", "");
    if (!raf) raf = requestAnimationFrame(place);
  });
  row.addEventListener("pointermove", (e) => { tx = e.clientX; ty = e.clientY; if (!raf) raf = requestAnimationFrame(place); });
  row.addEventListener("pointerleave", () => { on = false; peek.removeAttribute("data-on"); });
});
}
`;

const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Aniruddha Chaudhari</title>
${meta("Aniruddha Chaudhari")}
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap">
<style>${k.ISO_CSS}${css}${desk.css}${tower.css}${gearsFig.css}</style></head>
<body class="iso" data-theme="dark">${body}
<script type="module">${(kitScript() + pageScript + desk.live + tower.live + gearsFig.live).replace(/<\/(script)/gi, "<\\/$1")}</script>
</body></html>`;

writeFileSync(join(ROOT, "index.html"), html);
console.log("wrote mockups/iso-v1/index.html", `(${(html.length / 1024).toFixed(0)} KB)`, tower.stats);

// ---- projects.html ----
const ordered = [...featured, ...rest];
const rack = rackFigure(ordered);

const projectsBody = `
<div class="peek" aria-hidden="true"><img alt=""></div>
<div class="wrap">
${header("projects")}
  <main id="top">
    <section class="page-head">
      <div>
        <a class="back" href="index.html">← Home</a>
        <h1>Projects</h1>
        <p>Everything I've built and shipped, from a hackathon arcade to retrieval agents.</p>
      </div>
      <figure class="fig rack-fig" id="fig-rack" aria-hidden="true">${rack.svg}</figure>
    </section>
    <ul class="index index-all">${ordered.map(projectRow).join("")}</ul>
  </main>
  <footer class="foot"><span>© 2026 Aniruddha Chaudhari</span><span>Iso theme · mockup v1</span></footer>
</div>`;


const projectsHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Projects · Aniruddha Chaudhari</title>
${meta("Projects · Aniruddha Chaudhari")}
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap">
<style>${k.ISO_CSS}${css}${rack.css}</style></head>
<body class="iso" data-theme="dark">${projectsBody}
<script type="module">${(pageScript + rack.live).replace(/<\/(script)/gi, "<\\/$1")}</script>
</body></html>`;

writeFileSync(join(ROOT, "projects.html"), projectsHtml);
console.log("wrote mockups/iso-v1/projects.html", `(${(projectsHtml.length / 1024).toFixed(0)} KB)`);

// ---- favicon + link preview ----
writeFileSync(join(ROOT, "favicon.svg"), markSvg());

// the workstation as a finished, still frame: code typed, page built
const deskStill = desk.svg
  .replace(/data-w="([\d.]+)"([^>]*?)width="0"/g, 'data-w="$1"$2width="$1"')
  .replace(/class="dk-part"/g, 'class="dk-part" data-on=""')
  .replace("data-frame ", 'data-frame data-built="" ');

const ogHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Link preview</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap">
<style>${k.ISO_CSS}${css}${desk.css}
html,body{width:1200px;height:630px;overflow:hidden}
.og{position:relative;z-index:1;height:100%;display:grid;grid-template-columns:1fr 470px;align-items:center;gap:56px;padding:0 72px 0 84px}
.og-brand{display:flex;align-items:center;gap:12px;font-family:var(--anatomy-mono);font-size:19px;letter-spacing:.02em;color:var(--anatomy-strong)}
.og h1{font-size:66px;line-height:1.04;letter-spacing:-.025em;margin:44px 0 22px}
.og p{margin:0;font-size:27px;line-height:1.4;color:var(--anatomy-text);max-width:520px}
.og .fig{padding:20px 4px}
#fig-desk .dk-caret,#fig-desk .dk-mouse-led,#fig-desk .dk-steam path{animation:none}#fig-desk .dk-steam path{opacity:.4}#fig-desk .dk-part{transition:none}
</style></head>
<body class="iso" data-theme="dark">
<main class="og">
  <div>
    <div class="og-brand">${markSvg({ size: 34 })}<span>aniruddha.dev</span></div>
    <h1>Aniruddha Chaudhari</h1>
    <p>${ROLE}</p>
  </div>
  <figure class="fig" id="fig-desk">
    ${deskStill}
  </figure>
</main></body></html>`;
writeFileSync(join(HERE, "og.html"), ogHtml);
console.log("wrote favicon.svg, og.html (render og.png from og.html at 1200x630)");
