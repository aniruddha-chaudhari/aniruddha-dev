// Fig 1 · Contributions.
// The usual GitHub contribution graph, which tilts onto a bench plate and rises
// into a field of daily columns: each column as tall as that day's count.
import * as k from "../../.claude/skills/anatomy/kit/iso-kit.mjs";

const W = 640;
const H = 380;
const PITCH = 6;
const CELL = 4.6;
const RISE_MAX = 30;
const MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

export function contribFigure(raw, { username }) {
  // ---- truth: the model every number and motion comes from ----
  const days = raw.contributions.map((d) => ({ ...d, dt: new Date(d.date + "T00:00:00Z") }));
  const startDow = days[0].dt.getUTCDay();
  days.forEach((d, i) => {
    d.col = Math.floor((i + startDow) / 7);
    d.row = (i + startDow) % 7;
  });
  const COLS = days[days.length - 1].col + 1;
  const MAX = Math.max(...days.map((d) => d.count));
  const TOTAL = days.reduce((sum, d) => sum + d.count, 0);
  const ACTIVE = days.filter((d) => d.count).length;
  let streak = 0;
  for (let run = 0, i = 0; i < days.length; i++) {
    run = days[i].count ? run + 1 : 0;
    streak = Math.max(streak, run);
  }
  const busiest = days.reduce((a, b) => (b.count > a.count ? b : a));
  const dayLabel = (d) => `${MONTHS[d.dt.getUTCMonth()]} ${d.dt.getUTCDate()}`;
  const heightOf = (count) => (count ? 1.5 + RISE_MAX * Math.sqrt(count / MAX) : 0);

  // ---- world plan ----
  const GW = COLS * PITCH;
  const GD = 7 * PITCH;
  const PLATE = { x: -16, y: -16, w: GW + 32, d: 92, r: 9 };
  const PLATE_H = 8;
  const FOOT_H = 5;
  const RULER = { x: -4, y: 52, w: GW + 8, d: 6, r: 1 };

  const P = k.fitProjection(
    [...k.boxCorners(PLATE, -PLATE_H - FOOT_H, 0), ...k.boxCorners({ x: 0, y: 0, w: GW, d: GD }, 0, RISE_MAX + 2)],
    W,
    H,
    { pad: 30, azimuth: 60 },
  );
  const at = (p) => k.iso(p, P);
  const S = (paths, style) => k.solidSvg(paths, style);
  const L = (d, style) => k.lineSvg(d, style);
  const Dots = (pts, style) => k.dotsSvg(pts, style);
  const byDepth = (pts) => [...pts].sort((a, b) => k.depthOf([a[0], a[1], 0], P) - k.depthOf([b[0], b[1], 0], P));

  // grid-local (u, v) → screen, for the flat graph and for the floor of the plate
  const o = at([0, 0, 0]);
  const ex = at([1, 0, 0]);
  const ey = at([0, 1, 0]);
  const MISO = [ex[0] - o[0], ex[1] - o[1], ey[0] - o[0], ey[1] - o[1], o[0], o[1]];
  const s2 = (W - 96) / GW;
  const M2D = [s2, 0, 0, s2, (W - GW * s2) / 2 + 10, H / 2 - (GD * s2) / 2 + 4];
  const RISE = k.screenRise(1, P);

  function plate() {
    const out = [`<path class="iso-halo" d="${k.haloOf(PLATE, -PLATE_H - FOOT_H, PLATE_H, P)}"/>`];
    for (const [x, y] of byDepth(k.corners(PLATE, 20))) {
      out.push(S(k.cylinder(x, y, 7, -PLATE_H - FOOT_H, 1.6, P, 28), { tone: "lo" }));
      out.push(S(k.cylinder(x, y, 5.4, -PLATE_H - FOOT_H + 1.6, FOOT_H - 1.6, P, 28), { tone: "mid" }));
    }
    out.push(S(k.slabOf(PLATE, -PLATE_H, PLATE_H, P, 8, 1.4), { tone: "mid" }));
    out.push(L(k.planOutline(k.insetPlan(PLATE, 5), 0, P), { tone: "lo" }));
    const screws = k.corners(PLATE, 10);
    out.push(L(screws.map(([x, y]) => k.ring(x, y, 2.2, 0, P, 16)).join(""), { tone: "lo" }));
    out.push(Dots(screws.map(([x, y]) => at([x, y, 0])), { size: 0.5 }));
    // a shallow tray the grid sits in
    out.push(L(k.planOutline({ x: -2, y: -2, w: GW + 4, d: GD + 4, r: 1.5 }, 0, P, 3), { tone: "faint" }));
    // week ruler: one tick per week column, a long one where a month starts
    out.push(S(k.slabOf(RULER, 0, 0.6, P, 3), { tone: "lo", crease: "none" }));
    const ticks = { minor: [], major: [] };
    for (let c = 0; c < COLS; c++) {
      const x = c * PITCH + PITCH / 2;
      const first = days.find((d) => d.col === c && d.dt.getUTCDate() === 1);
      (first ? ticks.major : ticks.minor).push(k.lineOnTop([x, RULER.y], [x, RULER.y + (first ? 4 : 2)], 0.6, P));
    }
    out.push(L(ticks.minor.join(""), { tone: "lo" }), L(ticks.major.join(""), { tone: "mid" }));
    // engraved label plate at the back right
    const label = { x: GW - 46, y: -12, w: 52, d: 8, r: 1.2 };
    out.push(S(k.slabOf(label, 0, 0.8, P, 3), { tone: "lo", crease: "none" }));
    out.push(k.faceTextSvg(k.topMatrix([label.x + 4, label.y + 5.4], 0.8, P), username, { size: 3.2, tone: "mid" }));
    out.push(Dots([at([label.x + label.w - 3, label.y + label.d / 2, 0.8])], { size: 0.45 }));
    return out.join("");
  }

  function graphLabels() {
    const out = [];
    let lastMonth = -1;
    for (let c = 0; c < COLS; c++) {
      const d = days.find((x) => x.col === c);
      const m = d.dt.getUTCMonth();
      if (m !== lastMonth && c < COLS - 2) {
        out.push(`<text x="${c * PITCH + 0.6}" y="-3">${MONTHS[m]}</text>`);
        lastMonth = m;
      }
    }
    ["mon", "wed", "fri"].forEach((name, i) => out.push(`<text x="-3" y="${(1 + i * 2) * PITCH + PITCH * 0.72}" text-anchor="end">${name}</text>`));
    const lx = GW - 5 * PITCH - 1;
    out.push(`<text x="${lx - 2}" y="${GD + 7.3}" text-anchor="end">less</text>`);
    for (let l = 0; l < 5; l++) out.push(`<rect class="cb-swatch" data-l="${l}" x="${lx + l * PITCH}" y="${GD + 4}" width="${CELL}" height="${CELL}" rx="0.8"/>`);
    out.push(`<text x="${lx + 5 * PITCH + 1}" y="${GD + 7.3}">more</text>`);
    return `<g class="cb-labels" data-labels transform="matrix(${M2D.join(" ")})">${out.join("")}</g>`;
  }

  const cells = days
    .map((d) => ({
      u: d.col * PITCH + (PITCH - CELL) / 2,
      v: d.row * PITCH + (PITCH - CELL) / 2,
      h: heightOf(d.count),
      l: d.level,
      c: d.count,
      t: dayLabel(d),
      depth: k.depthOf([d.col * PITCH + PITCH / 2, d.row * PITCH + PITCH / 2, 0], P),
    }))
    .sort((a, b) => a.depth - b.depth)
    .map(({ depth, ...rest }) => rest);

  const defs = `<defs><filter id="cb-glow" filterUnits="userSpaceOnUse" x="0" y="0" width="${W}" height="${H}"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;

  const svg = k.figureSvg({
    width: W,
    height: H,
    label: `GitHub contributions for the last 12 months: ${TOTAL} in total over ${ACTIVE} days. Shown first as the usual contribution graph, then raised on a plate into one column per day, each as tall as that day's count. The busiest day was ${dayLabel(busiest)} with ${busiest.count}.`,
    body: [defs, `<g class="cb-plate" data-plate style="opacity:0">${plate()}</g>`, `<g class="cb-cells" data-cells></g>`, graphLabels()],
  });

  const DATA = { cells, M2D, MISO, RISE, CELL, total: TOTAL, active: ACTIVE, streak, busiest: `${dayLabel(busiest)} · ${busiest.count}` };

  const live = `{
const D = ${JSON.stringify(DATA)};
const root = document.getElementById("fig-contrib");
const svg = root.querySelector("svg");
const readout = root.querySelector("[data-readout]");
const button = document.querySelector("[data-raise]");
const status = root.querySelector("[data-status]");
const layer = svg.querySelector("[data-cells]");
const labels = svg.querySelector("[data-labels]");
const plate = svg.querySelector("[data-plate]");
const still = matchMedia("(prefers-reduced-motion: reduce)");
const NS = "http://www.w3.org/2000/svg";
const T_END = 2.0;
const cells = D.cells.map((c, i) => {
  const g = document.createElementNS(NS, "g");
  g.setAttribute("class", "cb-cell");
  g.dataset.l = c.l; g.dataset.i = i;
  const front = document.createElementNS(NS, "path"); front.setAttribute("class", "cb-cf");
  const side = document.createElementNS(NS, "path"); side.setAttribute("class", "cb-cs");
  const top = document.createElementNS(NS, "path"); top.setAttribute("class", "cb-ct");
  g.append(front, side, top);
  layer.append(g);
  return { ...c, g, front, side, top, up: false };
});
const clamp = (x) => Math.min(1, Math.max(0, x));
const ease = (x) => { x = clamp(x); return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
const out = (x) => 1 - Math.pow(1 - clamp(x), 3);
const f = (n) => n.toFixed(1);
let t = 0, target = 0, frame = 0, previous = 0, visible = false, played = false, drawn = "";

function draw() {
  const p = ease(t / 1.0);
  const r = out((t - 1.0) / 0.9);
  labels.style.opacity = (1 - clamp(t / 0.35)).toFixed(3);
  plate.style.opacity = clamp((t - 0.25) / 0.55).toFixed(3);
  root.toggleAttribute("data-raised", t >= T_END);
  const key = p.toFixed(4) + "|" + r.toFixed(4);
  if (key === drawn) return;
  drawn = key;
  const M = D.M2D.map((a, i) => a + (D.MISO[i] - a) * p);
  const map = (u, v, lift) => [M[0] * u + M[2] * v + M[4], M[1] * u + M[3] * v + M[5] - lift];
  for (const c of cells) {
    const lift = r * c.h * D.RISE;
    const u1 = c.u + D.CELL, v1 = c.v + D.CELL;
    const a = map(c.u, c.v, lift), b = map(u1, c.v, lift), cc = map(u1, v1, lift), d = map(c.u, v1, lift);
    c.top.setAttribute("d", "M" + f(a[0]) + " " + f(a[1]) + "L" + f(b[0]) + " " + f(b[1]) + "L" + f(cc[0]) + " " + f(cc[1]) + "L" + f(d[0]) + " " + f(d[1]) + "Z");
    if (lift > 0.05) {
      const bb = map(u1, c.v, 0), cg = map(u1, v1, 0), dg = map(c.u, v1, 0);
      c.front.setAttribute("d", "M" + f(d[0]) + " " + f(d[1]) + "L" + f(cc[0]) + " " + f(cc[1]) + "L" + f(cg[0]) + " " + f(cg[1]) + "L" + f(dg[0]) + " " + f(dg[1]) + "Z");
      c.side.setAttribute("d", "M" + f(cc[0]) + " " + f(cc[1]) + "L" + f(b[0]) + " " + f(b[1]) + "L" + f(bb[0]) + " " + f(bb[1]) + "L" + f(cg[0]) + " " + f(cg[1]) + "Z");
      c.up = true;
    } else if (c.up) {
      c.front.removeAttribute("d"); c.side.removeAttribute("d"); c.up = false;
    }
  }
}
function say(text) { if (readout.textContent !== text) readout.textContent = text; }
function rest() {
  if (target === 1 && t >= T_END) say("busiest " + D.busiest + " · streak " + D.streak + "d");
  else if (target === 0 && t <= 0) say(D.total + " contributions · " + D.active + " active days");
}
function tick(now) {
  const dt = previous ? Math.min((now - previous) / 1000, 1 / 30) : 1 / 60;
  previous = now;
  t = target ? Math.min(T_END, t + dt) : Math.max(0, t - dt * 1.4);
  draw();
  const moving = target ? t < T_END : t > 0;
  if (!moving) rest();
  frame = moving && visible ? requestAnimationFrame(tick) : 0;
}
function go(next) {
  target = next;
  button.textContent = next ? "Flat view" : "Raise it";
  button.setAttribute("aria-pressed", String(!!next));
  status.textContent = next ? "Raising the graph into columns." : "Showing the flat contribution graph.";
  if (still.matches) { t = next ? T_END : 0; draw(); rest(); return; }
  if (!frame) { previous = 0; frame = requestAnimationFrame(tick); }
}
button.addEventListener("click", () => { played = true; go(target ? 0 : 1); });
let hovered = null;
svg.addEventListener("pointerover", (event) => {
  const cell = event.target.closest(".cb-cell");
  if (!cell) return;
  if (hovered) hovered.removeAttribute("data-hover");
  hovered = cell; cell.setAttribute("data-hover", "");
  const c = cells[Number(cell.dataset.i)];
  say(c.t + " · " + c.c + (c.c === 1 ? " contribution" : " contributions"));
});
svg.addEventListener("pointerleave", () => { if (hovered) hovered.removeAttribute("data-hover"); hovered = null; rest(); });
new IntersectionObserver((entries) => {
  visible = entries[entries.length - 1].isIntersecting;
  if (visible && frame === 0 && (target ? t < T_END : t > 0)) { previous = 0; frame = requestAnimationFrame(tick); }
  if (visible && !played) { played = true; setTimeout(() => go(1), 1200); }
}, { threshold: 0.55 }).observe(svg);
root.__seek = (x) => { t = x; target = x > 0 ? 1 : 0; draw(); rest(); };
draw();
rest();
}
`;

  const css = `
#fig-contrib{--cell-0:#161b22;--cell-1:#0e4429;--cell-2:#006d32;--cell-3:#26a641;--cell-4:#39d353}
.iso[data-theme="light"] #fig-contrib{--cell-0:#ebedf0;--cell-1:#9be9a8;--cell-2:#40c463;--cell-3:#30a14e;--cell-4:#216e39}
#fig-contrib .cb-labels text{fill:var(--anatomy-muted);font-family:var(--anatomy-mono);font-size:3.6px;letter-spacing:.02em}
.cb-ct,.cb-swatch{fill:var(--cell-0)}
.cb-cell[data-l="1"] .cb-ct,.cb-swatch[data-l="1"]{fill:var(--cell-1)}
.cb-cell[data-l="2"] .cb-ct,.cb-swatch[data-l="2"]{fill:var(--cell-2)}
.cb-cell[data-l="3"] .cb-ct,.cb-swatch[data-l="3"]{fill:var(--cell-3)}
.cb-cell[data-l="4"] .cb-ct,.cb-swatch[data-l="4"]{fill:var(--cell-4)}
#fig-contrib[data-raised] .cb-cell[data-l="4"] .cb-ct{filter:var(--glow,none)}
.cb-cf{fill:var(--anatomy-shade-1);stroke:var(--anatomy-lo);stroke-width:.4px;vector-effect:non-scaling-stroke}
.cb-cs{fill:var(--anatomy-shade-3);stroke:var(--anatomy-lo);stroke-width:.4px;vector-effect:non-scaling-stroke}
.cb-cell[data-hover] .cb-ct{stroke:var(--anatomy-hi);stroke-width:.8px;vector-effect:non-scaling-stroke}
`;

  return { svg, live, css, stats: { total: TOTAL, active: ACTIVE, streak, busiest: `${dayLabel(busiest)} (${busiest.count})` } };
}
