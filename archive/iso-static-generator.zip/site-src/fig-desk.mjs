// Fig 0 · Workstation.
// A desk on a bench plate. The monitor shows an editor beside a live preview: as
// lines of code type themselves on the left, a small web page assembles itself on
// the right, piece by piece, then the build pulses and it starts again. Every
// typed character presses and lights a key. Steam rises from the mug, the phone
// lights with a notification after each build, the mouse LED breathes. Lit parts
// glow soft white.
import * as k from "../../.claude/skills/anatomy/kit/iso-kit.mjs";

const W = 640;
const H = 440;

const PLATE = { x: -118, y: -62, w: 236, d: 156, r: 10 };
const PLATE_H = 8;
const FOOT_H = 5;
const FOOT = { x: -30, y: -34, w: 60, d: 36, r: 6 };
const NECK = { x: -6, y: -20, w: 12, d: 6, r: 1.5 };
const HINGE = { x: -10, y: -18, w: 20, d: 10, r: 2 };
const HINGE_Z = 46;
const MON = { x: -82, y: -8, w: 164, d: 7, r: 2 };
const MON_Z0 = 40;
const MON_Z1 = 142;
const FRONT = MON.y + MON.d;
const SCREEN = { x0: -76, x1: 76, z0: 49, z1: 136 };
const KB = { x: -62, y: 26, w: 124, d: 48, r: 3 };
const KB_H = 4;
const KEY_H = 1.6;
const MOUSE = { x: 74, y: 44, w: 13, d: 20, r: 6 };
const PHONE = { x: -104, y: 44, w: 17, d: 32, r: 3 };
const MUG = { x: -96, y: -4, r: 7, h: 17 };

const ROWS = [
  [[1, "`"], [1, "1"], [1, "2"], [1, "3"], [1, "4"], [1, "5"], [1, "6"], [1, "7"], [1, "8"], [1, "9"], [1, "0"], [1, "-"], [1, "="], [1, "Backspace"]],
  [[1.5, "Tab"], [1, "q"], [1, "w"], [1, "e"], [1, "r"], [1, "t"], [1, "y"], [1, "u"], [1, "i"], [1, "o"], [1, "p"], [1, "["], [1, "]"], [1.5, "\\"]],
  [[1.75, "Caps"], [1, "a"], [1, "s"], [1, "d"], [1, "f"], [1, "g"], [1, "h"], [1, "j"], [1, "k"], [1, "l"], [1, ";"], [1, "'"], [2.25, "Enter"]],
  [[2.25, "Shift"], [1, "z"], [1, "x"], [1, "c"], [1, "v"], [1, "b"], [1, "n"], [1, "m"], [1, ","], [1, "."], [1, "/"], [2.75, "ShiftR"]],
  [[1.5, "Ctrl"], [1.5, "Alt"], [9, " "], [1.5, "AltR"], [1.5, "CtrlR"]],
];

// ---- the screen, in its own plane: local x = world x, local y = -z ----
const TOP_Y = -SCREEN.z1;
const BAR_H = 5;
const ED = { x0: SCREEN.x0 + 3, x1: -3 }; // editor pane
const PV = { x0: 3, x1: SCREEN.x1 - 3, y0: TOP_Y + BAR_H + 4, y1: -SCREEN.z0 - 4 }; // preview pane (browser frame)
const CODE_PITCH = 5.6;
const CODE_N = 13;

// deterministic code layout: each line is a few segments (indent, token widths, tone)
function codeLines() {
  let seed = 7;
  const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  const tones = ["kw", "id", "id", "str", "fn"];
  const indents = [0, 4, 8, 8, 4, 8, 12, 8, 4, 0, 4, 8, 4];
  return indents.map((indent, i) => {
    const segs = [];
    let x = ED.x0 + 9 + indent;
    const n = 1 + Math.floor(rnd() * 3);
    for (let s = 0; s < n && x < ED.x1 - 6; s++) {
      const w = Math.min(4 + Math.round(rnd() * 14), ED.x1 - 2 - x);
      segs.push({ x: +x.toFixed(1), w, tone: tones[(i + s) % tones.length] });
      x += w + 2.2;
    }
    return { y: +(TOP_Y + BAR_H + 6 + i * CODE_PITCH).toFixed(1), segs };
  });
}
const CODE = codeLines();

// the page the code builds, in the order its parts appear
const PAGE = (() => {
  const x0 = PV.x0 + 4;
  const x1 = PV.x1 - 4;
  const w = x1 - x0;
  const y = PV.y0 + 6;
  const cardW = (w - 4) / 3;
  return [
    { kind: "nav", shapes: [[x0, y, 5, 3, 0.6, "hi"], [x0 + w - 24, y + 0.6, 6, 1.8, 0.6, "lo"], [x0 + w - 16, y + 0.6, 6, 1.8, 0.6, "lo"], [x0 + w - 8, y + 0.6, 8, 1.8, 0.6, "lo"]] },
    { kind: "title", shapes: [[x0, y + 8, w * 0.55, 4.2, 0.8, "hi"], [x0, y + 13.4, w * 0.4, 4.2, 0.8, "hi"]] },
    { kind: "copy", shapes: [[x0, y + 20, w * 0.58, 1.8, 0.6, "lo"], [x0, y + 23.4, w * 0.48, 1.8, 0.6, "lo"]] },
    { kind: "button", shapes: [[x0, y + 28, 14, 4.6, 1.6, "accent"], [x0 + 16, y + 28, 12, 4.6, 1.6, "ghost"]] },
    { kind: "image", shapes: [[x0 + w * 0.66, y + 8, w * 0.34, 24.6, 1.4, "img"]] },
    { kind: "cards", shapes: [0, 1, 2].map((i) => [x0 + i * (cardW + 2), y + 38, cardW, 14, 1.2, "card"]) },
    { kind: "footer", shapes: [[x0, y + 56, w, 1.4, 0.6, "lo"]] },
  ];
})();

const P = k.fitProjection(
  [...k.boxCorners(PLATE, -PLATE_H - FOOT_H, 0), ...k.boxCorners(MON, MON_Z0, MON_Z1 + 4)],
  W,
  H,
  { pad: 26, azimuth: 63 },
);
const at = (p) => k.iso(p, P);
const S = (paths, style) => k.solidSvg(paths, style);
const L = (d, style) => k.lineSvg(d, style);
const Dots = (pts, style) => k.dotsSvg(pts, style);
const byDepth = (pts) => [...pts].sort((a, b) => k.depthOf([a[0], a[1], 0], P) - k.depthOf([b[0], b[1], 0], P));
const plane = (y) => k.sideMatrix([0, y], 0, P, "left");
const slot = (x0, z0, x1, z1, r) => k.pathOf(k.roundedPlan({ x: x0, y: -z1, w: x1 - x0, d: z1 - z0, r }, 3), true);
const f1 = (n) => n.toFixed(1);

function plate() {
  const out = [`<path class="iso-halo" d="${k.haloOf(PLATE, -PLATE_H - FOOT_H, PLATE_H, P)}"/>`];
  for (const [x, y] of byDepth(k.corners(PLATE, 22))) {
    out.push(S(k.cylinder(x, y, 7, -PLATE_H - FOOT_H, 1.6, P, 28), { tone: "lo" }));
    out.push(S(k.cylinder(x, y, 5.4, -PLATE_H - FOOT_H + 1.6, FOOT_H - 1.6, P, 28), { tone: "mid" }));
  }
  out.push(S(k.slabOf(PLATE, -PLATE_H, PLATE_H, P, 8, 1.4), { tone: "mid" }));
  out.push(L(k.planOutline(k.insetPlan(PLATE, 5), 0, P), { tone: "lo" }));
  const screws = k.corners(PLATE, 10);
  out.push(L(screws.map(([x, y]) => k.ring(x, y, 2.2, 0, P, 16)).join(""), { tone: "lo" }));
  out.push(Dots(screws.map(([x, y]) => at([x, y, 0])), { size: 0.5 }));
  const ruler = { x: -60, y: 82, w: 120, d: 5, r: 1 };
  out.push(S(k.slabOf(ruler, 0, 0.6, P, 3), { tone: "lo", crease: "none" }));
  const t = k.topTicks(ruler.x + 5, ruler.x + ruler.w - 5, 5, 5, ruler.y, 0.6, [1.8, 3.4], P);
  out.push(L(t.minor, { tone: "lo" }), L(t.major, { tone: "mid" }));
  out.push(`<path class="dk-pool" d="${k.haloOf({ x: -84, y: -2, w: 168, d: 60, r: 30 }, 0, 0.1, P)}"/>`);
  out.push(`<path class="dk-underglow" d="${k.haloOf(k.insetPlan(KB, -5), 0, 0.1, P)}"/>`);
  return out.join("");
}

function stand() {
  const out = [`<path class="iso-halo" d="${k.haloOf(FOOT, 0, 3, P)}"/>`];
  out.push(S(k.slabOf(FOOT, 0, 3, P, 6, 0.8), { tone: "mid" }));
  out.push(L(k.planOutline(k.insetPlan(FOOT, 3), 3, P, 6), { tone: "faint" }));
  out.push(S(k.slabOf(NECK, 3, HINGE_Z - 3, P, 3, 0.4), { tone: "mid" }));
  out.push(`<g transform="${plane(NECK.y + NECK.d)}">${L(slot(-2.6, 12, 2.6, 22, 2.6), { tone: "lo" })}</g>`);
  out.push(S(k.slabOf(HINGE, HINGE_Z, 9, P, 3, 0.4), { tone: "mid" }));
  out.push(Dots([at([-5, HINGE.y + HINGE.d, HINGE_Z + 4.5]), at([5, HINGE.y + HINGE.d, HINGE_Z + 4.5])], { size: 0.45 }));
  return out.join("");
}

function screenContent() {
  const out = [];
  // window chrome
  out.push(`<path class="dk-bar" d="M${SCREEN.x0} ${TOP_Y}H${SCREEN.x1}V${TOP_Y + BAR_H}H${SCREEN.x0}Z"/>`);
  out.push([0, 1, 2].map((i) => `<circle class="dk-dot" cx="${SCREEN.x0 + 4 + i * 4}" cy="${TOP_Y + 2.5}" r="1.1"/>`).join(""));
  out.push(`<path class="dk-divider" d="M0 ${TOP_Y + BAR_H}V${-SCREEN.z0}"/>`);
  // editor: gutter marks and the code bars (widths animate from 0)
  CODE.forEach((line, i) => {
    out.push(`<rect class="dk-gutter" x="${ED.x0 + 1}" y="${line.y}" width="3" height="1.8" rx="0.6"/>`);
    line.segs.forEach((s, j) => out.push(`<rect class="dk-code" data-tone="${s.tone}" data-l="${i}" data-s="${j}" data-w="${s.w}" x="${s.x}" y="${line.y}" width="0" height="2.2" rx="0.7"/>`));
  });
  out.push(`<rect class="dk-caret" data-caret x="${ED.x0 + 9}" y="${CODE[0].y - 0.6}" width="0.9" height="3.4"/>`);
  // preview: a browser frame and the page that assembles inside it
  out.push(`<rect class="dk-frame" data-frame x="${PV.x0}" y="${PV.y0}" width="${PV.x1 - PV.x0}" height="${PV.y1 - PV.y0}" rx="2"/>`);
  out.push(`<path class="dk-frame-bar" d="M${PV.x0 + 2} ${PV.y0}H${PV.x1 - 2}A2 2 0 0 1 ${PV.x1} ${PV.y0 + 2}V${PV.y0 + 3.4}H${PV.x0}V${PV.y0 + 2}A2 2 0 0 1 ${PV.x0 + 2} ${PV.y0}Z"/>`);
  out.push(`<rect class="dk-url" x="${PV.x0 + 10}" y="${PV.y0 + 1}" width="${PV.x1 - PV.x0 - 20}" height="1.4" rx="0.7"/>`);
  PAGE.forEach((part, i) => {
    out.push(`<g class="dk-part" data-part="${i}">${part.shapes.map(([x, y, w, h, r, tone]) => `<rect data-tone="${tone}" x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" rx="${r}"/>`).join("")}</g>`);
  });
  return out.join("");
}

function monitor() {
  const out = [];
  out.push(`<g transform="${plane(MON.y)}"><rect class="dk-bloom" x="${MON.x - 2}" y="${-MON_Z1 - 2}" width="${MON.w + 4}" height="${MON_Z1 - MON_Z0 + 4}" rx="6"/></g>`);
  out.push(S(k.slabOf(MON, MON_Z0, MON_Z1 - MON_Z0, P, 3, 0.6), { tone: "mid" }));
  const vents = [];
  for (let x = MON.x + 14; x <= MON.x + MON.w - 14; x += 4) vents.push(k.lineOnTop([x, MON.y + 2], [x, MON.y + MON.d - 2], MON_Z1, P));
  out.push(L(vents.join(""), { tone: "faint" }));
  const glass = `M${SCREEN.x0} ${-SCREEN.z1}H${SCREEN.x1}V${-SCREEN.z0}H${SCREEN.x0}Z`;
  out.push(`<g transform="${plane(FRONT)}">`);
  out.push(L(slot(MON.x + 2, MON_Z0 + 2, MON.x + MON.w - 2, MON_Z1 - 2, 1.4), { tone: "faint" }));
  out.push(`<clipPath id="dk-clip"><path d="${glass}"/></clipPath>`);
  out.push(`<path class="dk-glass" d="${glass}"/>`);
  out.push(`<g clip-path="url(#dk-clip)">`);
  out.push(`<path class="dk-haze" d="${slot(SCREEN.x0 + 10, SCREEN.z0 + 8, SCREEN.x1 - 10, SCREEN.z1 - 8, 20)}"/>`);
  out.push(screenContent());
  out.push(`<rect class="dk-vignette" x="${SCREEN.x0}" y="${-SCREEN.z1}" width="${SCREEN.x1 - SCREEN.x0}" height="${SCREEN.z1 - SCREEN.z0}" fill="url(#dk-vig)"/>`);
  out.push(`</g>`);
  out.push(L(glass, { tone: "lo" }));
  out.push(`<circle class="dk-power" cx="${SCREEN.x1 - 4}" cy="${-(MON_Z0 + 4.4)}" r="1.1"/>`);
  out.push(L(slot(-9, MON_Z0 + 3.4, 9, MON_Z0 + 5.4, 1), { tone: "lo" }));
  out.push(`</g>`);
  return `<g class="dk-monitor" data-monitor>${out.join("")}</g>`;
}

function mug() {
  const out = [`<path class="iso-halo" d="${k.haloOf({ x: MUG.x - MUG.r, y: MUG.y - MUG.r, w: MUG.r * 2, d: MUG.r * 2, r: MUG.r }, 0, 3, P)}"/>`];
  out.push(S(k.slabOf({ x: MUG.x + MUG.r - 1, y: MUG.y - 1.6, w: 5.4, d: 3.2, r: 1.2 }, 4, 9, P, 2), { tone: "lo" }));
  out.push(S(k.cylinder(MUG.x, MUG.y, MUG.r, 0, MUG.h, P, 36, 0.4), { tone: "mid" }));
  out.push(`<path class="dk-coffee" d="${k.ring(MUG.x, MUG.y, MUG.r - 1.2, MUG.h, P, 36)}"/>`);
  out.push(L(k.sideArc(MUG.x, MUG.y, MUG.r, 3, P, 36), { tone: "faint" }));
  const [cx, cy] = at([MUG.x, MUG.y, MUG.h]);
  const wisp = (dx) => `M${f1(cx + dx)} ${f1(cy - 1)}c-2.5 -4 2.5 -7 0 -11s2.5 -7 0 -11`;
  out.push(`<g class="dk-steam">${[-2.4, 0.4, 3].map((dx, i) => `<path d="${wisp(dx)}" style="--i:${i}"/>`).join("")}</g>`);
  return `<g class="dk-mug" data-mug>${out.join("")}</g>`;
}

const keyCodes = [];
function keyboard() {
  const out = [`<path class="iso-halo" d="${k.haloOf(KB, 0, 3, P)}"/>`];
  out.push(S(k.slabOf(KB, 0, KB_H, P, 4, 0.8), { tone: "mid" }));
  const U = 8;
  const x0 = KB.x + 6;
  const scale = (KB.w - 12) / (U * 15);
  ROWS.forEach((row, r) => {
    let x = x0;
    for (const [w, code] of row) {
      const plan = { x: x + 0.6, y: KB.y + 5 + r * U * 0.98 + 0.6, w: w * U * scale - 1.2, d: U * 0.98 - 1.6, r: 1 };
      out.push(`<g class="dk-key" data-k="${keyCodes.length}">${S(k.slabOf(plan, KB_H, KEY_H, P, 2, 0.3), { tone: "mid", crease: "faint" })}</g>`);
      keyCodes.push(code);
      x += w * U * scale;
    }
  });
  out.push(`<g class="dk-kbled">${Dots([at([KB.x + KB.w - 6, KB.y + 2.4, KB_H]), at([KB.x + KB.w - 10, KB.y + 2.4, KB_H])], { size: 0.55, tone: "hi" })}</g>`);
  return out.join("");
}

function mouse() {
  const out = [`<path class="iso-halo" d="${k.haloOf(MOUSE, 0, 2, P)}"/>`];
  out.push(S(k.slabOf(MOUSE, 0, 3.4, P, 8, 0.6), { tone: "mid" }));
  out.push(L(k.lineOnTop([MOUSE.x + MOUSE.w / 2, MOUSE.y + 1], [MOUSE.x + MOUSE.w / 2, MOUSE.y + 8], 3.4, P), { tone: "lo" }));
  out.push(L(k.lineOnTop([MOUSE.x + 1.2, MOUSE.y + 8], [MOUSE.x + MOUSE.w - 1.2, MOUSE.y + 8], 3.4, P), { tone: "faint" }));
  const led = at([MOUSE.x + MOUSE.w / 2, MOUSE.y + MOUSE.d - 3, 3.4]);
  out.push(`<circle class="dk-mouse-led" cx="${f1(led[0])}" cy="${f1(led[1])}" r="0.9"/>`);
  return `<g class="dk-mouse" data-mouse>${out.join("")}</g>`;
}

function phone() {
  const out = [`<path class="iso-halo" d="${k.haloOf(PHONE, 0, 1, P)}"/>`];
  out.push(S(k.slabOf(PHONE, 0, 1.8, P, 4, 0.4), { tone: "mid" }));
  const glassPlan = k.insetPlan(PHONE, 1.2);
  out.push(`<g class="dk-phone" data-phone><path class="dk-phone-glass" d="${k.onTop(k.roundedPlan(glassPlan, 4), 1.8, P, true)}"/>`);
  const card = { x: glassPlan.x + 1.5, y: glassPlan.y + 4, w: glassPlan.w - 3, d: 7, r: 1.4 };
  out.push(`<path class="dk-phone-card" d="${k.onTop(k.roundedPlan(card, 3), 1.8, P, true)}"/></g>`);
  out.push(Dots([at([PHONE.x + PHONE.w / 2, PHONE.y + 2.6, 1.8])], { size: 0.4, tone: "lo" }));
  return out.join("");
}

const defs = `<defs><filter id="dk-glow" filterUnits="userSpaceOnUse" x="0" y="0" width="${W}" height="${H}"><feGaussianBlur stdDeviation="1.3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="dk-soft" filterUnits="userSpaceOnUse" x="0" y="0" width="${W}" height="${H}"><feGaussianBlur stdDeviation="9"/></filter><radialGradient id="dk-vig" cx="50%" cy="45%" r="75%"><stop offset="60%" stop-color="#000" stop-opacity="0"/><stop offset="100%" stop-color="#000" stop-opacity=".45"/></radialGradient></defs>`;

export function deskFigure() {
  const svg = k.figureSvg({
    width: W,
    height: H,
    label: "A desk on a bench plate: a monitor showing a code editor beside a live preview, where a small web page assembles itself as the code is typed; a keyboard whose keys light up as it types, a mouse, a phone and a mug of coffee.",
    body: [defs, plate(), stand(), monitor(), mug(), keyboard(), mouse(), phone()],
  });

  const DATA = { code: CODE.map((l) => ({ y: l.y, segs: l.segs.map((s) => ({ x: s.x, w: s.w })) })), parts: PAGE.length, keys: keyCodes };
  const live = `{
const D = ${JSON.stringify(DATA)};
const root = document.getElementById("fig-desk");
const svg = root.querySelector("svg");
const readout = root.querySelector("[data-readout]");
const caret = svg.querySelector("[data-caret]");
const frame = svg.querySelector("[data-frame]");
const parts = [...svg.querySelectorAll("[data-part]")];
const keyEls = D.keys.map((_, i) => svg.querySelector('[data-k="' + i + '"]'));
const phone = svg.querySelector("[data-phone]");
const segEls = D.code.map((line, i) => line.segs.map((_, j) => svg.querySelector('[data-l="' + i + '"][data-s="' + j + '"]')));
const still = matchMedia("(prefers-reduced-motion: reduce)");
const LETTERS = "qwertyuiopasdfghjklzxcvbnm".split("").map((c) => D.keys.indexOf(c));
const ENTER = D.keys.indexOf("Enter"), SPACE = D.keys.indexOf(" "), SHIFT = D.keys.indexOf("Shift");
const down = axisVector(${JSON.stringify(P)}, [0, 0, -0.9]);
let timers = [], running = false, lines = 0, builds = 0;
const wait = (ms) => new Promise((res) => timers.push(setTimeout(res, ms)));
function say() { if (readout) readout.textContent = lines + " lines · " + builds + (builds === 1 ? " build" : " builds"); }
function press(i, ms = 110) {
  const el = keyEls[i];
  if (!el) return;
  el.setAttribute("data-on", "");
  el.setAttribute("transform", "translate(" + down[0].toFixed(2) + " " + down[1].toFixed(2) + ")");
  timers.push(setTimeout(() => { el.removeAttribute("data-on"); el.removeAttribute("transform"); }, ms));
}
function place(x, y) { caret.setAttribute("x", x.toFixed(1)); caret.setAttribute("y", (y - 0.6).toFixed(1)); }
function reset() {
  segEls.flat().forEach((el) => el.setAttribute("width", "0"));
  parts.forEach((el) => el.removeAttribute("data-on"));
  frame.removeAttribute("data-built");
  place(D.code[0].segs[0].x, D.code[0].y);
}
async function typeLine(i) {
  const line = D.code[i];
  root.setAttribute("data-busy", "");
  for (let j = 0; j < line.segs.length; j++) {
    const s = line.segs[j];
    for (let w = 0; w < s.w; w += 1.6) {
      if (!running) return;
      const now = Math.min(s.w, w + 1.6);
      segEls[i][j].setAttribute("width", now.toFixed(1));
      place(s.x + now + 0.4, line.y);
      if (Math.random() < 0.08) press(SHIFT, 150);
      press(LETTERS[Math.floor(Math.random() * LETTERS.length)]);
      await wait(55 + Math.random() * 70);
    }
    press(SPACE);
    await wait(90);
  }
  press(ENTER, 150);
  lines++; say();
  timers.push(setTimeout(() => root.removeAttribute("data-busy"), 900));
}
async function loop() {
  while (running) {
    reset();
    await wait(700);
    for (let i = 0; i < D.code.length && running; i++) {
      await typeLine(i);
      const show = Math.floor(((i + 1) / D.code.length) * D.parts) - 1;
      parts.forEach((el, n) => {
        if (n <= show && !el.hasAttribute("data-on")) { el.setAttribute("data-on", ""); el.setAttribute("data-new", ""); timers.push(setTimeout(() => el.removeAttribute("data-new"), 900)); }
      });
      await wait(160);
    }
    if (!running) return;
    frame.setAttribute("data-built", "");
    builds++; say();
    phone.setAttribute("data-on", "");
    timers.push(setTimeout(() => phone.removeAttribute("data-on"), 2400));
    await wait(3200);
  }
}
function start() { if (running || still.matches) return; running = true; loop(); }
function stop() { running = false; timers.forEach(clearTimeout); timers = []; }
say();
if (still.matches) {
  segEls.forEach((line, i) => line.forEach((el, j) => el.setAttribute("width", String(D.code[i].segs[j].w))));
  parts.forEach((el) => el.setAttribute("data-on", ""));
} else {
  reset();
  new IntersectionObserver((entries) => { entries[entries.length - 1].isIntersecting ? start() : stop(); }, { threshold: 0.2 }).observe(svg);
}
// ---- hands-on ----
const r0 = svg.getBoundingClientRect();
let inView = r0.bottom > 0 && r0.top < innerHeight; // until the observer reports
new IntersectionObserver((entries) => { inView = entries[entries.length - 1].isIntersecting; }, { threshold: 0.2 }).observe(svg);
const keyAt = (i) => keyEls[i] && keyEls[i].closest("[data-k]");
// run the pointer across the keyboard and each key it crosses goes down
svg.addEventListener("pointerover", (e) => {
  const k = e.target.closest("[data-k]");
  if (k) press(+k.dataset.k, 160);
});
// real typing presses the same keys while the desk is on screen
const NAMED = { " ": " ", Enter: "Enter", Backspace: "Backspace", Tab: "Tab", CapsLock: "Caps" };
const CODED = { ShiftLeft: "Shift", ShiftRight: "ShiftR", ControlLeft: "Ctrl", ControlRight: "CtrlR", AltLeft: "Alt", AltRight: "AltR" };
document.addEventListener("keydown", (e) => {
  if (!inView || e.metaKey || e.ctrlKey && !CODED[e.code]) return;
  const t = e.target;
  if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  const name = CODED[e.code] || NAMED[e.key] || (e.key.length === 1 ? e.key.toLowerCase() : null);
  const i = name == null ? -1 : D.keys.indexOf(name);
  if (i < 0) return;
  press(i, 140);
  root.setAttribute("data-busy", "");
  clearTimeout(press.busy);
  press.busy = setTimeout(() => root.removeAttribute("data-busy"), 700);
});
// click the monitor: a build goes out, the preview flashes and the phone pings
function notify() {
  phone.setAttribute("data-on", "");
  clearTimeout(notify.t);
  notify.t = setTimeout(() => phone.removeAttribute("data-on"), 2200);
}
svg.querySelector("[data-monitor]").addEventListener("click", () => {
  frame.removeAttribute("data-flash"); void frame.getBoundingClientRect(); frame.setAttribute("data-flash", "");
  frame.setAttribute("data-built", "");
  builds++; say();
  setTimeout(() => frame.removeAttribute("data-flash"), 700);
  notify();
});
svg.querySelector("[data-phone]").addEventListener("click", notify);
const mouseEl = svg.querySelector("[data-mouse]");
mouseEl.addEventListener("pointerdown", () => mouseEl.setAttribute("data-down", ""));
["pointerup", "pointerleave"].forEach((t) => mouseEl.addEventListener(t, () => mouseEl.removeAttribute("data-down")));
}
`;

  const mouseDown = k.axisVector(P, [0, 0, -1.2]);
  const css = `
#fig-desk{--desk-lit:#f1f4f8}
.iso[data-theme="light"] #fig-desk{--desk-lit:#262626}
#fig-desk .dk-glass{fill:#0b0c0d}
#fig-desk .dk-haze{fill:#fff;opacity:var(--screen-haze,.04);filter:blur(8px)}
#fig-desk .dk-bar{fill:#16181a}
#fig-desk .dk-dot{fill:#2e3134}
#fig-desk .dk-divider{fill:none;stroke:#1f2225;stroke-width:.6px;vector-effect:non-scaling-stroke}
#fig-desk .dk-gutter{fill:#26292c}
#fig-desk .dk-code{fill:#8d949a}
#fig-desk .dk-code[data-tone="kw"]{fill:#e9edf1}
#fig-desk .dk-code[data-tone="fn"]{fill:#c2c8ce}
#fig-desk .dk-code[data-tone="str"]{fill:#6b7278}
#fig-desk .dk-caret{fill:#f4f6f8;animation:dk-blink 1.06s steps(1,end) infinite;filter:var(--glow-fig,none)}
#fig-desk .dk-frame{fill:#111315;stroke:#2a2e31;stroke-width:.5px;vector-effect:non-scaling-stroke;transition:stroke .4s}
#fig-desk .dk-frame[data-built]{stroke:#f4f6f8;filter:var(--glow-fig,none)}
#fig-desk .dk-frame-bar{fill:#1b1e21}
#fig-desk .dk-url{fill:#2a2e31}
#fig-desk .dk-part{opacity:0;transform:translateY(1.6px);transition:opacity .45s cubic-bezier(.32,.72,0,1),transform .45s cubic-bezier(.32,.72,0,1)}
#fig-desk .dk-part[data-on]{opacity:1;transform:none}
#fig-desk .dk-part[data-new]{filter:var(--glow-fig,none)}
#fig-desk .dk-part [data-tone="hi"]{fill:#e9edf1}
#fig-desk .dk-part [data-tone="lo"]{fill:#565c62}
#fig-desk .dk-part [data-tone="accent"]{fill:#f4f6f8}
#fig-desk .dk-part [data-tone="ghost"]{fill:none;stroke:#565c62;stroke-width:.5px;vector-effect:non-scaling-stroke}
#fig-desk .dk-part [data-tone="img"]{fill:#24282b}
#fig-desk .dk-part [data-tone="card"]{fill:#1c1f22;stroke:#2c3034;stroke-width:.5px;vector-effect:non-scaling-stroke}
#fig-desk .dk-vignette{pointer-events:none}
#fig-desk .dk-power{fill:var(--desk-lit);filter:var(--glow-fig,none)}
#fig-desk .dk-pool{fill:#fff;opacity:var(--pool,0);filter:blur(16px)}
#fig-desk .dk-bloom{fill:#fff;opacity:var(--bloom,0);filter:url(#dk-soft)}
#fig-desk .dk-underglow{fill:#fff;opacity:calc(var(--pool,0) * .6);filter:blur(10px);transition:opacity .6s}
#fig-desk[data-busy] .dk-underglow{opacity:calc(var(--pool,0) * 2.4)}
#fig-desk .dk-key .iso-top{transition:fill .3s}
#fig-desk .dk-key[data-on] .iso-top{fill:var(--desk-lit);transition:none}
#fig-desk .dk-key[data-on] .iso-edge{stroke:var(--desk-lit)}
#fig-desk .dk-key[data-on]{filter:var(--glow-fig,none)}
#fig-desk .dk-kbled circle{fill:var(--desk-lit)!important;opacity:.9!important}
#fig-desk .dk-mouse-led{fill:var(--desk-lit);animation:dk-breathe 3.2s ease-in-out infinite;filter:var(--glow-fig,none)}
#fig-desk .dk-coffee{fill:var(--anatomy-shade-0)}
#fig-desk :is([data-monitor],[data-phone],[data-mouse],[data-mug]){cursor:pointer}
#fig-desk [data-k]{cursor:default}
#fig-desk .dk-frame[data-flash]{stroke:#fff;filter:var(--glow-fig,none);animation:dk-flash .7s ease-out}
@keyframes dk-flash{0%{stroke-width:2px}100%{stroke-width:.5px}}
#fig-desk .dk-mouse{transition:transform .08s}
#fig-desk .dk-mouse[data-down]{transform:translate(${mouseDown[0].toFixed(2)}px,${mouseDown[1].toFixed(2)}px)}
#fig-desk .dk-mouse[data-down] .dk-mouse-led,#fig-desk .dk-mouse:hover .dk-mouse-led{animation:none;opacity:1}
#fig-desk .dk-mug:hover .dk-steam path{animation-duration:1.8s;stroke:var(--anatomy-hi)}
#fig-desk .dk-steam path{fill:none;stroke:var(--anatomy-mid);stroke-width:.9px;vector-effect:non-scaling-stroke;stroke-linecap:round;opacity:0;animation:dk-steam 3.6s ease-in-out infinite;animation-delay:calc(var(--i) * 1.2s)}
#fig-desk .dk-phone-glass{fill:var(--anatomy-shade-0);transition:fill .5s}
#fig-desk .dk-phone-card{fill:transparent;transition:fill .5s}
#fig-desk .dk-phone[data-on] .dk-phone-glass{fill:#16181a}
#fig-desk .dk-phone[data-on] .dk-phone-card{fill:var(--desk-lit);opacity:.8}
#fig-desk .dk-phone[data-on]{filter:var(--glow-fig,none)}
@keyframes dk-blink{50%{opacity:0}}
@keyframes dk-breathe{0%,100%{opacity:.25}50%{opacity:1}}
@keyframes dk-steam{0%{opacity:0;transform:translateY(2px)}30%{opacity:.7}100%{opacity:0;transform:translateY(-10px)}}
@media (prefers-reduced-motion:reduce){#fig-desk .dk-caret,#fig-desk .dk-mouse-led,#fig-desk .dk-steam path{animation:none}#fig-desk .dk-steam path{opacity:.4}#fig-desk .dk-part{transition:none}}
`;
  return { svg, live, css };
}
