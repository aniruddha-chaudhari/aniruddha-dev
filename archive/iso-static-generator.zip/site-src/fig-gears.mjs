// Contact plate · Gear train.
// Four spur gears lying flat on axles over a base plate, meshed tooth to tooth.
// The big gear is cranked; each play() spins the train up, runs it, and winds it
// down, every gear turning at its true ratio and in alternating directions.
// A status light glows while it runs and the readout counts output turns.
import * as k from "../../.claude/skills/anatomy/kit/iso-kit.mjs";

const W = 440;
const H = 330;
const M = 2.3; // tooth module: pitch radius = M * teeth / 2
const PLATE_H = 6;
const GEAR_Z = 12; // underside of every gear
const GEAR_T = 4; // gear thickness
const TURN = 7.2; // seconds per turn of the driver at full speed

// the train, from the cranked driver outward: teeth, and the direction to the next centre
const TRAIN = [
  { teeth: 30, toNext: -38 },
  { teeth: 14, toNext: 22 },
  { teeth: 22, toNext: 104 },
  { teeth: 11 },
];
const rad = (d) => (d * Math.PI) / 180;
const GEARS = (() => {
  const out = [];
  let x = -30, y = 14, phase = 0;
  TRAIN.forEach((g, i) => {
    const r = (M * g.teeth) / 2;
    if (i > 0) {
      const prev = out[i - 1];
      const a = TRAIN[i - 1].toNext;
      x = prev.x + (prev.r + r) * Math.cos(rad(a));
      y = prev.y + (prev.r + r) * Math.sin(rad(a));
      // mesh: a tooth gap of this gear faces the tooth of the previous one at the contact line
      phase = a + 180 + 180 / g.teeth - (TRAIN[i - 1].teeth / g.teeth) * (prev.phase - a);
    }
    out.push({ ...g, x, y, r, phase, dir: i % 2 ? -1 : 1, period: (TURN * g.teeth) / TRAIN[0].teeth });
  });
  return out;
})();

const bounds = (() => {
  const xs = GEARS.flatMap((g) => [g.x - g.r - 13, g.x + g.r + 13]);
  const ys = GEARS.flatMap((g) => [g.y - g.r - 13, g.y + g.r + 13]);
  return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), d: Math.max(...ys) - Math.min(...ys) };
})();
const PLATE = { ...bounds, r: 8 };

const P = k.fitProjection(k.boxCorners(PLATE, -PLATE_H, GEAR_Z + GEAR_T + 14), W, H, { pad: 16, azimuth: 40 });
const S = (paths, style) => k.solidSvg(paths, style);
const L = (d, style) => k.lineSvg(d, style);
const f1 = (n) => +n.toFixed(2);

// a spur gear outline around (0, 0) in its own plane
function gearPath(teeth, r) {
  const tip = r + M, root = r - 1.25 * M, step = (Math.PI * 2) / teeth;
  const pts = [];
  for (let i = 0; i < teeth; i++) {
    const t = i * step;
    [[-0.5, root], [-0.27, root], [-0.17, tip], [0.17, tip], [0.27, root]].forEach(([f, rr]) => pts.push([Math.cos(t + f * step) * rr, Math.sin(t + f * step) * rr]));
  }
  return "M" + pts.map(([x, y]) => `${f1(x)} ${f1(y)}`).join("L") + "Z";
}
function webPath(r) {
  // lightening holes between hub and rim
  const holes = [];
  const n = r > 20 ? 5 : r > 14 ? 4 : 0;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2, c = r * 0.55, hr = r * 0.2;
    holes.push(`M${f1(Math.cos(a) * c + hr)} ${f1(Math.sin(a) * c)}a${f1(hr)} ${f1(hr)} 0 1 0 ${f1(-2 * hr)} 0a${f1(hr)} ${f1(hr)} 0 1 0 ${f1(2 * hr)} 0`);
  }
  return holes.join("");
}

function plate() {
  const out = [`<path class="iso-halo" d="${k.haloOf(PLATE, -PLATE_H, PLATE_H, P)}"/>`];
  out.push(S(k.slabOf(PLATE, -PLATE_H, PLATE_H, P, 8, 1), { tone: "mid" }));
  out.push(L(k.planOutline(k.insetPlan(PLATE, 4), 0, P), { tone: "faint" }));
  const [lx, ly] = k.iso([PLATE.x + PLATE.w - 8, PLATE.y + 8, 0], P);
  out.push(`<circle class="gr-status" cx="${f1(lx)}" cy="${f1(ly)}" r="1.5"/>`);
  return out.join("");
}

function gear(g, i) {
  const out = [];
  // axle and its boss on the plate
  out.push(S(k.cylinder(g.x, g.y, 4.2, 0, 3, P, 24, 0.3), { tone: "mid" }));
  out.push(S(k.cylinder(g.x, g.y, 2, 3, GEAR_Z - 3, P, 16), { tone: "mid", crease: "none" }));
  // the gear body: stacked outlines give it thickness, the top one carries the detail
  const spin = `class="gr-spin" data-g="${i}"`;
  const shape = gearPath(g.teeth, g.r);
  const layers = [0, 1, 2, 3].map((n) => {
    const z = GEAR_Z + (GEAR_T * n) / 3;
    const top = n === 3;
    return `<g transform="${k.topMatrix([g.x, g.y], z, P)}"${top && i === 0 ? " data-plane" : ""}><g ${spin}><g transform="rotate(${f1(g.phase)})">` +
      `<path class="${top ? "gr-top" : "gr-side"}" d="${shape}${top ? "" : ""}"/>` +
      (top ? `<path class="gr-web" d="${webPath(g.r)}"/><circle class="gr-hub" r="${f1(Math.max(4.4, g.r * 0.24))}"/><circle class="gr-mark" cx="${f1(g.r * 0.62)}" r="1"/>` : "") +
      `</g></g></g>`;
  });
  out.push(`<g class="gr-gear" data-gear="${i}">${layers.join("")}</g>`);
  // axle cap above the gear
  out.push(S(k.cylinder(g.x, g.y, 2.6, GEAR_Z + GEAR_T, 2.2, P, 18, 0.3), { tone: "mid", className: "gr-cap" }));
  if (i === 0) {
    // crank: an arm across the driver and a handle, turning with it
    const arm = `<g transform="${k.topMatrix([g.x, g.y], GEAR_Z + GEAR_T + 2.2, P)}"><g ${spin}><rect class="gr-arm" x="-2.4" y="-2.4" width="${f1(g.r * 0.78)}" height="4.8" rx="2.4"/><circle class="gr-knob" cx="${f1(g.r * 0.7)}" r="3"/></g></g>`;
    out.push(`<g class="gr-crank">${arm}</g>`);
  }
  return out.join("");
}

export function gearsFigure() {
  const defs = `<defs><filter id="gr-glow" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
  // back to front so nearer gears overlap farther ones
  const order = GEARS.map((g, i) => ({ g, i })).sort((a, b) => k.depthOf([a.g.x, a.g.y, 0], P) - k.depthOf([b.g.x, b.g.y, 0], P));
  const svg = k.figureSvg({
    width: W,
    height: H,
    label: "Four meshing spur gears on axles over a base plate, driven by a crank on the largest gear, each turning at its own ratio.",
    body: [defs, plate(), ...order.map(({ g, i }) => gear(g, i))],
  });

  const ratio = TRAIN[0].teeth / TRAIN[TRAIN.length - 1].teeth;
  const live = `{
const root = document.getElementById("fig-gears");
const svg = root.querySelector("svg");
const plane = svg.querySelector("[data-plane]"); // the driver's top face: its own x/y plane, centred on the axle
const T = ${JSON.stringify(GEARS.map((g) => g.teeth))}, D = ${JSON.stringify(GEARS.map((g) => g.dir))};
const spins = [...svg.querySelectorAll("[data-g]")].map((el) => [el, +el.dataset.g]);
const BASE = 360 / ${TURN}; // driver speed, degrees per second
const calm = matchMedia("(prefers-reduced-motion: reduce)");
let angle = 0, vel = 0, target = 0, raf = 0, prev = 0, drag = null;
function paint() {
  spins.forEach(([el, g]) => { el.style.transform = "rotate(" + (angle * (T[0] / T[g]) * D[g]).toFixed(2) + "deg)"; });
  root.toggleAttribute("data-run", Math.abs(vel) > 4 || !!drag);
}
function frame(t) {
  const dt = Math.min(0.05, (t - (prev || t)) / 1000);
  prev = t;
  if (!drag) { vel += (target - vel) * Math.min(1, dt * 1.4); angle += vel * dt; }
  paint();
  raf = requestAnimationFrame(frame);
}
function run(on) { if (on && !raf) { prev = 0; raf = requestAnimationFrame(frame); } else if (!on && raf) { cancelAnimationFrame(raf); raf = 0; } }
new IntersectionObserver((e) => run(e[e.length - 1].isIntersecting), { threshold: 0 }).observe(svg);
// drag the train round by any gear; letting go keeps the spin, which eases back to the motor's speed
function angleAt(e) {
  const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(plane.getScreenCTM().inverse());
  return Math.atan2(p.y, p.x) * 180 / Math.PI;
}
svg.addEventListener("pointerdown", (e) => {
  if (!e.target.closest(".gr-gear, .gr-crank")) return;
  e.preventDefault();
  svg.setPointerCapture(e.pointerId);
  drag = { a: angleAt(e), t: performance.now() };
  root.setAttribute("data-drag", "");
});
svg.addEventListener("pointermove", (e) => {
  if (!drag) return;
  const a = angleAt(e), now = performance.now();
  let d = a - drag.a;
  if (d > 180) d -= 360; else if (d < -180) d += 360;
  angle += d;
  vel = vel * 0.6 + (d / Math.max(0.008, (now - drag.t) / 1000)) * 0.4;
  drag = { a, t: now };
  paint();
});
function release() { if (!drag) return; drag = null; root.removeAttribute("data-drag"); if (calm.matches) vel = 0; }
svg.addEventListener("pointerup", release);
svg.addEventListener("pointercancel", release);
target = calm.matches ? 0 : BASE;
}
`;

  const css = `
#fig-gears{--gr-top:#eceef0;--gr-side:#8c9095;--gr-edge:#5d6166;--gr-lit:#f1f4f8}
.iso:not([data-theme="light"]) #fig-gears{--glow-fig:url(#gr-glow)}
.iso[data-theme="light"] #fig-gears{--gr-top:#2a2a2d;--gr-side:#0e0e10;--gr-edge:#000;--gr-lit:#1a1a1a}
#fig-gears .gr-side{fill:var(--gr-side);stroke:var(--gr-side);stroke-width:.6px;vector-effect:non-scaling-stroke}
#fig-gears .gr-top{fill:var(--gr-top);stroke:var(--gr-edge);stroke-width:.6px;vector-effect:non-scaling-stroke;stroke-linejoin:round}
#fig-gears .gr-web{fill:var(--gr-side);stroke:var(--gr-edge);stroke-width:.5px;vector-effect:non-scaling-stroke}
#fig-gears .gr-hub{fill:none;stroke:var(--gr-edge);stroke-width:.6px;vector-effect:non-scaling-stroke}
#fig-gears .gr-mark{fill:var(--gr-edge)}
#fig-gears .gr-arm{fill:var(--gr-top);stroke:var(--gr-edge);stroke-width:.6px;vector-effect:non-scaling-stroke}
#fig-gears .gr-knob{fill:var(--gr-lit);stroke:var(--gr-edge);stroke-width:.6px;vector-effect:non-scaling-stroke}
#fig-gears[data-run] .gr-knob{filter:var(--glow-fig,none)}
#fig-gears .gr-status{fill:var(--anatomy-lo);transition:fill .3s}
#fig-gears[data-run] .gr-status{fill:var(--gr-lit);filter:var(--glow-fig,none)}
.iso[data-theme="light"] #fig-gears[data-run] .gr-status{fill:#111}
#fig-gears :is(.gr-gear,.gr-crank){cursor:grab}
#fig-gears[data-drag],#fig-gears[data-drag] *{cursor:grabbing}
#fig-gears svg{touch-action:pan-y}
`;
  return { svg, live, css };
}
