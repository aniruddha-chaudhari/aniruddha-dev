// Site mark: a solid letter A pushed back into isometric depth, on a dark tile.
// The front face stays flat and square-on so it still reads as an "A" at 16px;
// only the walls behind it carry the iso angle.

// front face, clockwise; the counter is a separate hole
const OUTER = [[12.2, 8], [15.8, 8], [22, 26], [18.4, 26], [17.16, 22.4], [10.84, 22.4], [9.6, 26], [6, 26]];
const HOLE = [[14, 13.23], [16.06, 19.2], [11.94, 19.2]];
const DEPTH = [2.6, -1.5]; // straight back along the iso x axis (30deg)

const TONES = { face: "#f2f2f2", top: "#9b9b9b", side: "#4d4d4d", back: "#2a2a2a", tile: "#0b0b0c", rim: "#ffffff1f" };

const f = (n) => +n.toFixed(2);
const shift = ([x, y]) => [x + DEPTH[0], y + DEPTH[1]];
const pathOf = (pts) => "M" + pts.map(([x, y]) => `${f(x)} ${f(y)}`).join("L") + "Z";
const area = (pts) => pts.reduce((a, [x, y], i) => { const [u, v] = pts[(i + 1) % pts.length]; return a + x * v - u * y; }, 0) / 2;

// a wall for every edge whose outside faces back along DEPTH; deepest walls painted first
function walls(ring, outside) {
  const cw = area(ring) > 0; // y points down, so positive area means clockwise on screen
  const out = [];
  ring.forEach((a, i) => {
    const b = ring[(i + 1) % ring.length];
    const ex = b[0] - a[0], ey = b[1] - a[1], len = Math.hypot(ex, ey);
    let nx = -ey / len, ny = ex / len; // left normal
    if (cw === outside) { nx = -nx; ny = -ny; }
    if (nx * DEPTH[0] + ny * DEPTH[1] <= 0) return;
    const mid = (a[0] + b[0]) * DEPTH[0] + (a[1] + b[1]) * DEPTH[1];
    out.push({ d: pathOf([a, b, shift(b), shift(a)]), tone: ny < -0.5 ? TONES.top : TONES.side, mid });
  });
  return out;
}

export function markSvg({ size = 32, tile = true } = {}) {
  const sides = [...walls(OUTER, true), ...walls(HOLE, false)].sort((p, q) => p.mid - q.mid);
  const face = pathOf(OUTER) + pathOf(HOLE);
  const back = pathOf(OUTER.map(shift)) + pathOf(HOLE.map(shift));
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="${size}" height="${size}">` +
    (tile ? `<rect width="32" height="32" rx="7" fill="${TONES.tile}"/><rect x=".5" y=".5" width="31" height="31" rx="6.5" fill="none" stroke="${TONES.rim}"/>` : "") +
    `<path d="${back}" fill="${TONES.back}" fill-rule="evenodd"/>` +
    sides.map((s) => `<path d="${s.d}" fill="${s.tone}" stroke="${s.tone}" stroke-width=".15" stroke-linejoin="round"/>`).join("") +
    `<path d="${face}" fill="${TONES.face}" fill-rule="evenodd"/></svg>`;
}
