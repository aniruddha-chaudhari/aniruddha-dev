// Projects page · Server rack.
// A small rack cabinet holding one unit per project, top to bottom in list
// order. Live projects blink a green activity light; code-only ones stay dim.
// Hovering a project in the list slides its unit out and lights its edges.
// On load the units slide in one after another.
import * as k from "../../.claude/skills/anatomy/kit/iso-kit.mjs";

const W = 300;
const H = 380;

const CAB = { x: -32, y: -26, w: 64, d: 52, r: 2.5 };
const WALL = 3;
const FOOT_H = 4;
const BASE_Z = FOOT_H + 4; // floor of the bay
const UNIT_H = 9.6;
const GAP = 2;
const SLIDE = 20; // how far a unit comes out

export function rackFigure(projects) {
  const n = projects.length;
  const TOP_Z = BASE_Z + n * (UNIT_H + GAP) + 2;
  const P = k.fitProjection(
    [...k.boxCorners(CAB, 0, TOP_Z + WALL), ...k.boxCorners({ ...CAB, d: CAB.d + SLIDE }, 0, 0)],
    W,
    H,
    { pad: 16, azimuth: 56 },
  );
  const at = (p) => k.iso(p, P);
  const S = (paths, style) => k.solidSvg(paths, style);
  const L = (d, style) => k.lineSvg(d, style);
  const f1 = (v) => +v.toFixed(2);
  const FRONT = CAB.y + CAB.d;
  const face = (y) => k.sideMatrix([0, y], 0, P, "left");

  // the cabinet behind the units: floor, back, and the left wall (hidden side, drawn for the silhouette)
  function shell() {
    const out = [`<path class="iso-halo" d="${k.haloOf(CAB, 0, TOP_Z, P)}"/>`];
    for (const [x, y] of k.corners(CAB, 4)) out.push(S(k.slabOf({ x: x - 3, y: y - 3, w: 6, d: 6, r: 1 }, 0, FOOT_H, P, 2), { tone: "lo", crease: "none" }));
    out.push(S(k.slabOf(CAB, FOOT_H, BASE_Z - FOOT_H, P, 3, 0.4), { tone: "mid" }));
    out.push(S(k.slabOf({ x: CAB.x, y: CAB.y, w: CAB.w, d: WALL, r: 0.5 }, BASE_Z, TOP_Z - BASE_Z, P, 1), { tone: "mid", crease: "none" }));
    out.push(S(k.slabOf({ x: CAB.x, y: CAB.y, w: WALL, d: CAB.d, r: 0.5 }, BASE_Z, TOP_Z - BASE_Z, P, 1), { tone: "mid", crease: "none" }));
    return out.join("");
  }

  // the side wall nearest the viewer and the roof, drawn over the units
  function frame() {
    const out = [];
    out.push(S(k.slabOf({ x: CAB.x + CAB.w - WALL, y: CAB.y, w: WALL, d: CAB.d, r: 0.5 }, BASE_Z, TOP_Z - BASE_Z, P, 1), { tone: "mid" }));
    for (let i = 0; i < 6; i++) out.push(L(k.segment([CAB.x + CAB.w, CAB.y + 8 + i * 6, BASE_Z + 10], [CAB.x + CAB.w, CAB.y + 8 + i * 6, TOP_Z - 10], P), { tone: "faint" }));
    out.push(S(k.slabOf(CAB, TOP_Z, WALL, P, 3, 0.5), { tone: "mid" }));
    const vents = [];
    for (let x = CAB.x + 10; x <= CAB.x + CAB.w - 10; x += 5) vents.push(k.lineOnTop([x, CAB.y + 10], [x, CAB.y + CAB.d - 10], TOP_Z + WALL, P));
    out.push(L(vents.join(""), { tone: "faint" }));
    return out.join("");
  }

  function unit(p, i) {
    const z = TOP_Z - 2 - (i + 1) * (UNIT_H + GAP) + GAP; // list order runs top to bottom
    const plan = { x: CAB.x + WALL + 0.6, y: CAB.y + WALL + 1, w: CAB.w - 2 * WALL - 1.2, d: CAB.d - WALL - 1.6, r: 0.6 };
    const out = [S(k.slabOf(plan, z, UNIT_H, P, 1, 0.3), { tone: "mid", className: "rk-body" })];
    const fy = plan.y + plan.d;
    const x0 = plan.x + 3, x1 = plan.x + plan.w - 3;
    const zm = -(z + UNIT_H / 2);
    const vents = [];
    for (let x = x0 + 2; x < x0 + 22; x += 2.6) vents.push(`M${f1(x)} ${f1(zm - 2.6)}V${f1(zm + 2.6)}`);
    out.push(`<g transform="${face(fy)}">` +
      `<path class="rk-vent" d="${vents.join("")}"/>` +
      `<rect class="rk-bay" x="${f1(x0 + 26)}" y="${f1(zm - 1.6)}" width="14" height="3.2" rx="0.8"/>` +
      `<circle class="rk-led" data-live="${Boolean(p.live)}" style="--d:${((i * 0.37) % 1.3).toFixed(2)}s" cx="${f1(x1 - 6)}" cy="${f1(zm)}" r="1.15"/>` +
      `<circle class="rk-pwr" cx="${f1(x1 - 1.5)}" cy="${f1(zm)}" r="0.8"/>` +
      `<path class="rk-handle" d="M${f1(x0 - 1)} ${f1(zm - 3)}v6M${f1(x1 + 1)} ${f1(zm - 3)}v6"/></g>`);
    return `<g class="rk-unit" data-unit="${i}" style="--i:${i}">${out.join("")}</g>`;
  }

  const defs = `<defs><filter id="rk-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
  // bottom units first, so each one sits over the one below
  const units = projects.map((p, i) => ({ p, i })).reverse().map(({ p, i }) => unit(p, i));
  const svg = k.figureSvg({
    width: W,
    height: H,
    label: `A server rack with ${n} units, one per project. Live projects blink a green activity light.`,
    body: [defs, shell(), ...units, frame()],
  });

  const slide = k.axisVector(P, [0, SLIDE, 0]);
  const enter = k.axisVector(P, [0, SLIDE * 1.6, 0]);

  const live = `{
const root = document.getElementById("fig-rack");
if (root) {
  const units = [...root.querySelectorAll("[data-unit]")];
  const rows = [...document.querySelectorAll(".index-all .idx")];
  function pull(i, from) {
    units.forEach((u) => u.toggleAttribute("data-out", +u.dataset.unit === i));
    rows.forEach((r, n) => r.toggleAttribute("data-hl", from === "rack" && n === i));
  }
  // the list drives the rack
  rows.forEach((row, i) => {
    row.addEventListener("pointerenter", () => pull(i, "list"));
    row.addEventListener("pointerleave", () => pull(-1));
    row.addEventListener("focusin", () => pull(i, "list"));
    row.addEventListener("focusout", () => pull(-1));
  });
  // and the rack drives the list: hover a unit to pull it, click to open the project
  units.forEach((u) => {
    const i = +u.dataset.unit, row = rows[i];
    if (!row) return;
    u.addEventListener("pointerenter", () => pull(i, "rack"));
    u.addEventListener("pointerleave", () => pull(-1));
    u.addEventListener("click", () => window.open(row.querySelector(".idx-name").href, "_blank", "noopener"));
  });
  setTimeout(() => root.setAttribute("data-ready", ""), 80); // a timer, not rAF, so a background tab still shows the units
}
}
`;

  const css = `
#fig-rack{--rk-lit:#f1f4f8}
.iso:not([data-theme="light"]) #fig-rack{--glow-fig:url(#rk-glow)}
.iso[data-theme="light"] #fig-rack{--rk-lit:#1a1a1a}
#fig-rack .rk-unit{transform:translate(${f1(enter[0])}px,${f1(enter[1])}px);opacity:0;transition:transform .5s cubic-bezier(.32,.72,0,1),opacity .35s}
#fig-rack[data-ready] .rk-unit{transform:none;opacity:1;transition-delay:calc(.15s + var(--i) * 70ms)}
#fig-rack[data-ready] .rk-unit[data-out]{transform:translate(${f1(slide[0])}px,${f1(slide[1])}px);transition-delay:0s}
#fig-rack .rk-unit{cursor:pointer}
#fig-rack .rk-unit[data-out]>.rk-body>.iso-edge{stroke:var(--rk-lit)}
#fig-rack .rk-unit[data-out]>.rk-body{filter:var(--glow-fig,none)}
#fig-rack .rk-vent,#fig-rack .rk-handle{fill:none;stroke:var(--anatomy-lo);stroke-width:.6px;vector-effect:non-scaling-stroke;stroke-linecap:round}
#fig-rack .rk-bay{fill:var(--anatomy-shade-0);stroke:var(--anatomy-lo);stroke-width:.5px;vector-effect:non-scaling-stroke}
#fig-rack .rk-pwr{fill:var(--anatomy-mid)}
#fig-rack .rk-led{fill:var(--anatomy-faint);stroke:var(--anatomy-lo);stroke-width:.5px;vector-effect:non-scaling-stroke}
#fig-rack .rk-led[data-live="true"]{fill:var(--green);stroke:none;filter:var(--glow-fig,none);animation:rk-blink 1.3s steps(1,end) infinite;animation-delay:var(--d)}
#fig-rack .rk-unit[data-out] .rk-pwr{fill:var(--rk-lit)}
@keyframes rk-blink{0%,100%{opacity:1}40%{opacity:.35}55%{opacity:1}70%{opacity:.5}}
@media (prefers-reduced-motion:reduce){#fig-rack .rk-unit{transition:none}#fig-rack .rk-led{animation:none!important}}
`;
  return { svg, live, css };
}
